package com.gopush.protocol.device;


/**
 * go-push
 *
 * @类功能说明：设备消息响应基类
 * @作者：chenxiangqi
 * @创建时间：2017/6/9
 * @VERSION：
 */
public abstract class DeviceMessageResp extends DeviceMessage {



}
