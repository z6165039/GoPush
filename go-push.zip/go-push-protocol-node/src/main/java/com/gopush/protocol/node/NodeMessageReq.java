package com.gopush.protocol.node;

/**
 * go-push
 *
 * @类功能说明：节点服务请求消息基类
 * @作者：chenxiangqi
 * @创建时间：2017/6/9
 * @VERSION：
 */
public abstract class NodeMessageReq extends NodeMessage {
}
