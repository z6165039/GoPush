package com.gopush.protocol.node;
/**
 * go-push
 *
 * @类功能说明：设备下线上报响应
 * @作者：chenxiangqi
 * @创建时间：2017/6/9
 * @VERSION：
 */
public class DeviceDisconResp extends NodeMessageResp{
}
