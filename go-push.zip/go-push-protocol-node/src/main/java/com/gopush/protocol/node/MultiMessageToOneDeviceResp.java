package com.gopush.protocol.node;
/**
 * go-push
 *
 * @类功能说明：多条消息发送给单个设备
 * @作者：chenxiangqi
 * @创建时间：2017/6/9
 * @VERSION：
 */
public class MultiMessageToOneDeviceResp extends NodeMessageResp{
}
