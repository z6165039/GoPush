package com.gopush.protocol.node;

/**
 * go-push
 *
 * @类功能说明：Ping-Pong
 * @作者：chenxiangqi
 * @创建时间：2017/6/9
 * @VERSION：
 */
public class Ping extends NodeMessageReq {
}
